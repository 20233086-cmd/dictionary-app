# Dictly — Từ điển Anh - Việt tích hợp Chatbot AI

Ứng dụng web quản lý & tra cứu từ điển Anh - Việt xây dựng bằng **Spring Boot** (backend REST API)
và **HTML/CSS/JS thuần** (frontend riêng biệt), tích hợp **chatbot AI thật** (Google Gemini — miễn phí)
hỗ trợ học tiếng Anh.

## 1. Tính năng chính

- 🔍 Tra cứu từ điển Anh → Việt: nghĩa, phiên âm, ví dụ, từ đồng nghĩa, cấp độ (A1–C2)
- ⚡ Gợi ý từ khi gõ (autocomplete), phát âm bằng giọng đọc trình duyệt (Web Speech API)
- ⭐ Lưu từ yêu thích, xem lại lịch sử tra cứu (yêu cầu đăng nhập)
- 📅 "Từ vựng hôm nay", bảng xếp hạng từ được tra nhiều nhất, thống kê tổng số từ
- 🤖 AI Tutor cho USER: học từ vựng, ngữ pháp, dịch câu, sửa câu và luyện tiếng Anh
- 🛠️ AI Admin Assistant cho ADMIN: đọc số liệu hệ thống, phân tích xu hướng, đề xuất nội dung và tạo báo cáo
  - Tự động biến các từ vựng có trong từ điển thành **link bấm-để-tra** ngay trong câu trả lời của bot
  - 2 chế độ: **Hỏi đáp** (Q&A) và **Luyện hội thoại** (bot đóng vai bạn nói tiếng Anh, tự sửa lỗi ngữ pháp)
- 🔁 **Tra ngược Việt → Anh**: gõ nghĩa tiếng Việt để tìm từ tiếng Anh tương ứng
- 🗂️ **Flashcard ôn tập theo thuật toán SM-2** (giống Anki): tự tính lịch ôn tập tiếp theo dựa trên mức độ nhớ của bạn
- 📝 **Quiz trắc nghiệm hàng ngày**: tự sinh câu hỏi từ các từ cần ôn, chấm điểm ngay
- 🔐 Đăng ký / đăng nhập bằng JWT, phân quyền USER / ADMIN
- 🛠️ Trang quản trị: thêm / sửa / xoá từ vựng, quản lý nhiều nghĩa cho mỗi từ, tìm kiếm & phân trang
- 🎨 Giao diện hiện đại, thiết kế riêng (không dùng theme mặc định), responsive

## 2. Kiến trúc & công nghệ

| Thành phần | Công nghệ |
|---|---|
| Backend | Spring Boot 3.3, Spring Data JPA, Spring Security + JWT (jjwt) |
| Database | MySQL |
| Chatbot AI | Google Gemini API (gọi qua Spring WebClient) |
| Frontend | HTML5 / CSS3 thuần / JavaScript (Vanilla, không cần build tool) |

Backend và frontend là **hai project độc lập**, giao tiếp qua REST API (JSON), có thể triển khai riêng biệt.

```
dictionary-app/
├── backend/     → Spring Boot project (Maven)
└── frontend/    → HTML/CSS/JS thuần, chạy bằng bất kỳ static server nào
```

## 3. Cài đặt Backend

### 3.1. Yêu cầu
- JDK 17 trở lên
- Maven 3.8+
- MySQL Server 8.0 trở lên đang chạy

### 3.2. Tạo database

Không cần tạo bảng thủ công (Hibernate tự tạo/cập nhật bảng), chỉ cần đảm bảo MySQL đang chạy.
Có thể tự tạo trước database (tuỳ chọn, vì cấu hình đã bật `createDatabaseIfNotExist=true`):

```sql
CREATE DATABASE dictionary_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 3.3. Cấu hình `backend/src/main/resources/application.properties`

Mở file và chỉnh 3 phần sau:

```properties
# Thông tin đăng nhập MySQL của bạn
spring.datasource.url=jdbc:mysql://localhost:3306/dictionary_db?useSSL=false&serverTimezone=Asia/Ho_Chi_Minh&createDatabaseIfNotExist=true
spring.datasource.username=root
spring.datasource.password=your_mysql_password    # <-- đổi thành mật khẩu MySQL thật

# Chuỗi bí mật ký JWT — đổi thành chuỗi ngẫu nhiên dài (>= 32 ký tự)
app.jwt.secret=CHANGE_THIS_SECRET_KEY_TO_SOMETHING_LONG_AND_RANDOM_1234567890

# API key Gemini (xem hướng dẫn lấy key miễn phí ở mục 5 bên dưới)
gemini.api.key=DÁN_API_KEY_CỦA_BẠN_VÀO_ĐÂY
```

> ⚠️ Không cấu hình `gemini.api.key` thì toàn bộ ứng dụng vẫn chạy bình thường
> (tra từ, yêu thích, lịch sử, quản trị...) — chỉ riêng **chatbot AI** sẽ trả lời
> một thông báo nhắc cấu hình key thay vì trả lời thật.

### 3.4. Chạy backend

```bash
cd backend
mvn spring-boot:run
```

Backend sẽ chạy tại: **http://localhost:8080**

Khi khởi động lần đầu, hệ thống tự động:
- Tạo tài khoản quản trị: **username: `admin`  /  password: `admin123`**
- Seed sẵn 10 từ vựng mẫu để bạn có dữ liệu thử ngay

> Đổi mật khẩu admin sau khi đăng nhập lần đầu (hiện tại chưa có màn hình đổi mật khẩu trong bản này —
> có thể đổi trực tiếp trong bảng `users` hoặc bổ sung thêm tính năng này sau).

## 4. Chạy Frontend

Frontend là các file tĩnh (HTML/CSS/JS), không cần build. Có 2 cách chạy đơn giản:

**Cách 1 — VS Code Live Server (khuyên dùng):**
Mở thư mục `frontend/` bằng VS Code, cài extension "Live Server", chuột phải vào `index.html` → "Open with Live Server".

**Cách 2 — Python (có sẵn trên hầu hết máy):**
```bash
cd frontend
python3 -m http.server 5500
```
Sau đó mở trình duyệt tại: **http://localhost:5500**

> ⚠️ Nếu backend chạy ở địa chỉ/cổng khác `http://localhost:8080`, hãy sửa lại trong file
> `frontend/js/config.js`:
> ```js
> const API_BASE_URL = "http://localhost:8080/api";
> ```

## 5. Lấy API key Gemini MIỄN PHÍ cho Chatbot

1. Truy cập **https://aistudio.google.com/apikey**
2. Đăng nhập bằng tài khoản Google (không cần thẻ tín dụng)
3. Bấm **"Create API key"** → chọn hoặc tạo một Google Cloud project
4. Copy API key vừa tạo, dán vào `backend/src/main/resources/application.properties`:
   ```properties
   gemini.api.key=AIzaSy...................
   ```
5. Khởi động lại backend

Free tier hiện áp dụng cho các model dòng Flash (`gemini-2.5-flash`, `gemini-2.5-flash-lite`),
đủ dùng cho nhu cầu học tập / demo (khoảng 10–15 request/phút, không giới hạn thời gian dùng thử).

Nếu muốn đổi sang model khác, sửa dòng:
```properties
gemini.api.model=gemini-2.5-flash-lite
```

## 6. Tài khoản mặc định

| Vai trò | Username | Password |
|---|---|---|
| Quản trị viên | `admin` | `admin123` |

Người dùng thường tự đăng ký tại trang **Đăng ký**.

## 7. Danh sách API chính

| Method | Endpoint | Mô tả | Yêu cầu đăng nhập |
|---|---|---|---|
| POST | `/api/auth/register` | Đăng ký | Không |
| POST | `/api/auth/login` | Đăng nhập | Không |
| GET | `/api/words/lookup/{english}` | Tra từ | Không |
| GET | `/api/words/search?keyword=&page=&size=` | Tìm kiếm có phân trang | Không |
| GET | `/api/words/suggest?prefix=` | Gợi ý từ | Không |
| GET | `/api/words/word-of-day` | Từ vựng hôm nay | Không |
| GET | `/api/words/most-viewed?limit=` | Top từ được tra nhiều | Không |
| POST/PUT/DELETE | `/api/admin/words/**` | CRUD từ vựng | **ADMIN** |
| GET/POST/DELETE | `/api/favorites/**` | Quản lý yêu thích | **USER** |
| GET/DELETE | `/api/history` | Lịch sử tra cứu | **USER** |
| POST | `/api/chatbot/message` | Gửi tin nhắn tới chatbot AI | **USER** |
| POST | `/api/ai/tutor/chat` | Chat với AI Tutor | **USER** |
| POST | `/api/ai/tutor/correct` | AI sửa câu | **USER** |
| GET | `/api/admin/ai/overview` | Snapshot số liệu cho AI Admin | **ADMIN** |
| POST | `/api/admin/ai/chat` | Chat với AI Admin Assistant | **ADMIN** |

Tất cả response đều theo dạng chuẩn:
```json
{ "success": true, "message": "OK", "data": { ... } }
```

## 8. Gợi ý mở rộng (nếu muốn phát triển thêm)

- Xác thực email khi đăng ký, quên mật khẩu
- Đổi mật khẩu, cập nhật hồ sơ cá nhân
- Import/export từ vựng hàng loạt qua Excel/CSV
- Flashcard ôn tập từ vựng theo thuật toán lặp lại ngắt quãng (spaced repetition)
- Thêm hình ảnh minh hoạ cho từ vựng
- Triển khai production: đổi `spring.jpa.hibernate.ddl-auto=update` → `validate`, dùng Flyway/Liquibase để quản lý migration

## 9. Xử lý sự cố thường gặp

| Lỗi | Nguyên nhân thường gặp |
|---|---|
| Backend không kết nối được MySQL | Sai username/password, hoặc MySQL chưa chạy — kiểm tra lại `application.properties` |
| Frontend báo "Không thể kết nối tới máy chủ" | Backend chưa chạy, hoặc `API_BASE_URL` trong `config.js` sai cổng |
| Chatbot trả lời "chưa được cấu hình API key" | Chưa dán Gemini API key vào `application.properties`, hoặc key sai/hết hạn |
| Lỗi CORS trên console trình duyệt | Đảm bảo đang gọi đúng `API_BASE_URL`; cấu hình CORS trong `SecurityConfig.java` đã cho phép mọi origin ở chế độ phát triển |
| Đăng nhập admin nhưng không thấy menu "Quản trị" | Kiểm tra lại tài khoản có đúng `role = ADMIN` trong bảng `users` không |

## Tính năng Dictly 2.0 đã bổ sung
- Trung tâm học tập `/dashboard.html`: tổng quan từ điển, yêu thích, flashcard, thẻ đến hạn, lịch sử và Word of the Day.
- Học theo chủ đề `/topics.html`: Technology, Education, Work & Career, Environment, Communication, Personal Development, Travel, Daily English.
- AI sửa câu `/ai.html`: kiểm tra ngữ pháp/chính tả và gợi ý cách diễn đạt tự nhiên qua Gemini.
- Word có trường `topic`, quản trị viên có thể phân loại từ khi thêm/sửa.
- Thanh điều hướng được mở rộng với Học tập và Chủ đề.


## AI tách biệt theo vai trò

- `ai.html` → **AI Tutor**, dành cho người dùng học tiếng Anh.
- `admin-ai.html` → **AI Admin Assistant**, chỉ tài khoản ADMIN truy cập được.
- Backend bảo vệ `/api/ai/tutor/**` và `/api/admin/ai/**` bằng Spring Security + JWT.
